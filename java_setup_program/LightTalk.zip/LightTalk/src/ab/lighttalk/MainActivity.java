package ab.lighttalk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	public void buttontimer(View view) {
		Intent myIntent = new Intent(this, TimerActivity.class);
		this.startActivity(myIntent);
	}

	public void buttontimersetup(View view) {
		Intent myIntent = new Intent(this, TimerSetupActivity.class);
		this.startActivity(myIntent);
	}

	
	
	
	public void buttonalarm(View view) {
		Intent myIntent = new Intent(this, AlarmActivity.class);
		this.startActivity(myIntent);

	}

	
	public void buttonvoltmerclock(View view) {
		Intent myIntent = new Intent(this, VoltmeterClockActivity.class);


	 	
			
	 		this.startActivity(myIntent);

	}

	
	
	
	
}
