package ab.lighttalk;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

public class VoltmeterClockActivity extends Activity {

	EditText editText = null;

	Blinker bl = null;

	@Override
	protected void onDestroy() {
		super.onDestroy();
		bl = null;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_voltmeterclock);

		View viewBackground = null;
		ImageView viewLamp = null;
		TextView textViewCounter = null;

		viewBackground = this.findViewById(R.id.linearLayoutVC);
		viewLamp = (ImageView) this.findViewById(R.id.imagelampVC);
		editText = (EditText) this.findViewById(R.id.editTextVC);
		textViewCounter = (TextView) this.findViewById(R.id.textViewCounterVC);

		bl = new Blinker();
		bl.initblinker(4, 1, this, viewBackground, viewLamp, textViewCounter);

	}

	public void buttonyymmddhhmm(View view) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("yyMMddHHmm");
		editText.setText(format1.format(cal.getTime()));
		buttonsend(null);
	}

	public void buttonsend(View view) {

		bl.startTimerCountDown(editText.getText().toString());

		View iview = this.getCurrentFocus();
		if (iview != null) {
			InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
			imm.hideSoftInputFromWindow(iview.getWindowToken(), 0);
		}
	}

}
