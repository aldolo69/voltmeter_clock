package ab.lighttalk;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

public class AlarmActivity extends Activity {

	// EditText editText = null;

	// MediaPlayer mPlayer = null;

	/*
	 * Timer timer;// timer used to run the task TimerTask timerTask;// timer
	 * task Handler mHandlerLight;// handler used by task to talk to main thread
	 * 
	 * Timer timerCountDown;// timer used to run the task TimerTask
	 * timerTaskCountDown;// timer task Handler mHandlerCountDown;// handler
	 * used by task to talk to main thread
	 */
	/*
	 * boolean bBlack = true;// present state of the screen String strMsg =
	 * null;// message to be sent int iStrIndex = 0;// char in process byte
	 * byteMsg;// char in process int iStatus = 0;// 0=stop,1=begin of tx,2=tx
	 * ,3=eot // bot=10 bit 0 + 1 // eof=9 bit 0 int iCounter = 0;// int iBit =
	 * -1;// -1=do nothing.0=0,1=1 first step,2=1second step int iBitPerChar =
	 * 8;
	 */
	// 0 bit is sent with a short deltaT, 1 bit is sent with a long
	// deltaT

	Blinker bl = null;

	/*
	 * void showLamp() { if (bBlack == false) {
	 * viewBackground.setBackgroundColor(getResources().getColor(
	 * android.R.color.holo_orange_light));
	 * viewLamp.setImageDrawable(getResources().getDrawable(
	 * R.drawable.light_bulb_white)); } else {
	 * viewBackground.setBackgroundColor(getResources().getColor(
	 * android.R.color.darker_gray));
	 * viewLamp.setImageDrawable(getResources().getDrawable(
	 * R.drawable.light_bulb_black)); } }
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		bl = null;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setContentView(R.layout.activity_alarm);

		View viewBackground = null;
		ImageView viewLamp = null;

		TextView textViewCounter = null;
		Switch sw = null;

		viewBackground = this.findViewById(R.id.linearLayout0);
		viewLamp = (ImageView) this.findViewById(R.id.imagelamp);
		// editText = (EditText) this.findViewById(R.id.editText);
		textViewCounter = (TextView) this.findViewById(R.id.textViewCounter);
		// sw = (Switch) this.findViewById(R.id.switch1);
		// mPlayer = MediaPlayer.create(this, R.raw.tick);

		bl = new Blinker();
		bl.initblinker(4, 1, this, viewBackground, viewLamp, textViewCounter);

		/*
		 * mHandlerCountDown = new Handler() { public void handleMessage(Message
		 * msg) { iCounter--; if (iCounter != 0) { mPlayer.start();// sound
		 * textViewCounter.setText((new Integer(iCounter)).toString()); } else {
		 * textViewCounter.setText("");
		 * 
		 * timerCountDown.cancel(); timerTaskCountDown.cancel();
		 * timerTaskCountDown = null; timerCountDown = null;
		 * startTimerTransmission(); }
		 * 
		 * } };
		 * 
		 * mHandlerLight = new Handler() { public void handleMessage(Message
		 * msg) { // will land here 2 times per DeltaTime. if the bit // we are
		 * sending is zero then toggle, otherwise // wait for the next switch
		 * (iBit) { case -1:// do nothing and go to check next bit break; case
		 * 0:// toggle and go to check next bit // Log.w("LightTalk", "0");
		 * bBlack = !bBlack; showLamp(); break; case 2:// toggle and go to check
		 * next bit bBlack = !bBlack; showLamp(); break; case 1:// do nothing
		 * and exit!!! // Log.w("LightTalk", "1"); iBit = 2; return;// n }
		 * 
		 * // now decide next bit switch (iStatus) { case 0:// start trasmission
		 * bBlack = true; showLamp(); iStrIndex = 0; iStatus = 1; iCounter = 0;
		 * iBit = 0; return; case 1:// send start of transmission iBit = 0;
		 * iCounter++; // usually keep 0. last tick send 1 if (iCounter == 15) {
		 * iBit = 1; iStatus = 2; iCounter = 0; return; } return; case 2:// send
		 * data if (iCounter == iBitPerChar) { iCounter = 0; iBit = 1; return;//
		 * send end of byte } if (iCounter == 0) { // first bit of the new byte
		 * 
		 * // eostring? if (iStrIndex == strMsg.length()) { iBit = 0; iStatus =
		 * 3; iCounter = 0; return; }
		 * 
		 * char charMsg = strMsg.charAt(iStrIndex); byteMsg = (byte) (charMsg &
		 * 0x00FF); // only numeric string?
		 * 
		 * if (sw.isChecked() == false) { // if (strMsg.matches("[0-9]+") &&
		 * strMsg.length() > // 0) { iBitPerChar = 4; byteMsg -= 48;// ascii for
		 * '0' } else { iBitPerChar = 8; if (strMsg.matches("[0-9]+"))//tutti
		 * numeri { iStrIndex++; charMsg = strMsg.charAt(iStrIndex); byteMsg -=
		 * 48; byteMsg += 16 * (((byte) (charMsg & 0x00FF))-48); }
		 * 
		 * }
		 * 
		 * // Log.w("LightTalk", new // Character(charMsg).toString());
		 * iStrIndex++; }
		 * 
		 * if ((byteMsg & (1 << iCounter)) > 0) { iBit = 1; } else { iBit = 0; }
		 * 
		 * // Log.w("LightTalk", "Sent " + new // Integer(iBit).toString());
		 * 
		 * iCounter++; return; case 3:// send eot iBit = 0; iCounter++; if
		 * (iCounter == 11) { iBit = -1; bBlack = true; showLamp();
		 * viewLamp.setImageDrawable(getResources().getDrawable(
		 * R.drawable.light_bulb_transparent));
		 * 
		 * getWindow().clearFlags(
		 * WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); timer.cancel();
		 * timerTask.cancel(); timerTask = null; timer = null; return; } return;
		 * }
		 * 
		 * } };
		 */
	}

 
/*	public void buttonhhmmss(View view) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("HHmmss");
		editText.setText(format1.format(cal.getTime()));
		buttonsend(null);
	}

	public void buttonyymmddhhmm(View view) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("yyMMddHHmm");
		editText.setText(format1.format(cal.getTime()));
		buttonsend(null);
	}

	public void buttonyyyymmddhhmmss(View view) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("yyyyMMddHHmmss");
		editText.setText(format1.format(cal.getTime()));
		buttonsend(null);
	}
*/
	/*
	 * void startTimerTransmission() { strMsg = editText.getText().toString();
	 * iStrIndex = 0; iStatus = 0;// 0=stop,1=begin of tx,2=tx 0,3=eot
	 * 
	 * if (timer != null) { timer.cancel(); timer = null; } if (timerTask !=
	 * null) { timerTask.cancel(); timerTask = null; } timerTask = new
	 * TimerTask() { public void run() {
	 * mHandlerLight.obtainMessage(1).sendToTarget(); } };
	 * 
	 * timer = new Timer(); timer.schedule(timerTask, 100, 100); //
	 * getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }
	 * 
	 * void startTimerCountDown() { iCounter = 4;
	 * 
	 * if (timerCountDown != null) { timerCountDown.cancel(); timerCountDown =
	 * null; } if (timerTaskCountDown != null) { timerTaskCountDown.cancel();
	 * timerTaskCountDown = null; } timerTaskCountDown = new TimerTask() {
	 * public void run() { mHandlerCountDown.obtainMessage(1).sendToTarget(); }
	 * };
	 * 
	 * timerCountDown = new Timer(); timerCountDown.schedule(timerTaskCountDown,
	 * 1000, 1000); // }
	 */

	public void button0(View view) {
		bl.startTimerCountDown("0");
	}

	public void button9(View view) {
		bl.startTimerCountDown("9");
	}

	public void button1(View view) {
		bl.startTimerCountDown("1");
	}

	public void button2(View view) {
		bl.startTimerCountDown("2");
	}

	public void button3(View view) {
		bl.startTimerCountDown("3");
	}

	public void button4(View view) {
		bl.startTimerCountDown("4");
	}

	public void buttonhhmm(View view) {
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat format1 = new SimpleDateFormat("HHmm");
		bl.startTimerCountDown(format1.format(cal.getTime()));
	}

	/*
	 * public void buttonsend(View view) {
	 * 
	 * bl.startTimerCountDown(editText.getText().toString()); //
	 * startTimerCountDown();
	 * 
	 * View iview = this.getCurrentFocus(); if (iview != null) {
	 * InputMethodManager imm = (InputMethodManager)
	 * getSystemService(Context.INPUT_METHOD_SERVICE);
	 * imm.hideSoftInputFromWindow(iview.getWindowToken(), 0); } }
	 */

}
